var count=0;
function incrementCount(){
    
    var inccount=document.querySelector('p');
    inccount.innerText="count value is : "+ ++count;
}